# Anonymous output-analysis archive

Executed model-input messages, free-text scenario queries and reconstruction source are not included. Scientific model outputs, assignments, numerical catalogues, verified coding labels and analytical routines are retained. **Full protocol replication is PARTIEL.**

```bash
python -m pip install -r revised_8000/analysis/requirements.txt
python -B revised_8000/analysis/reproduce.py
python -B revised_8000/analysis/reproduce_mechanisms.py
python -B revised_8000/analysis/check_release.py
```

No model call or new annotation is performed. Initial human coding agreement is verified at 392/400 (98.0%; kappa 0.965). Final harmonized-record/NLP agreement is separately 388/400 (97.0%). Generated responses are retained as outputs, not presented as experimental instructions. Personal source-workbook metadata, Git history and hosting account information are excluded.
