# Anonymous replication package

This distribution supports offline analytical replication of 8,000 archived GPT/Claude responses. It contains no Git repository/history, hosting account/profile information, author/coder identities, source Office creator metadata, correspondence or private local filesystem paths. Synthetic experimental and provider record identifiers are retained for scientific matching; they are not participant identities. Original scientific values and labels are unchanged.

```bash
python -m pip install -r revised_8000/analysis/requirements.txt
python -B revised_8000/analysis/reproduce.py
python -B revised_8000/analysis/reproduce_mechanisms.py
python -B revised_8000/analysis/check_release.py
```

The first two analytical commands block network sockets and require no API credentials. Results are generated from the included exact requests/responses and existing coding labels. Initial coding agreement is 392/400 (98%; Cohen's kappa 0.965); final harmonized-record/NLP concordance is separately 388/400 (97%). The control is targeted, with no population-accuracy or actual-consumer-exposure claim.

Only immutable inputs and reference outputs are distributed; fresh analytical outputs are produced by the commands. See revised_8000/README.md for the complete protocol and limitations.
